import java.util.*;
/**
 * 
 */
public class Test
{
    public static void main(String args[])
    {
        System.out.println('\u000C');
        Random random = new Random();
        int n = 70;     //orders per month
        int m=10;        //number of couriers
        int months=4;   //number of months
        int range = 100;
        Integer courierTotal[] = new Integer[m];    //number of orders for each courier
        Integer orderCust[] = new Integer[n];       //number of items for each customer
        String customerNames[] = new String[n];     //names of the customers
        Courier[] courierValues=new Courier[m];     //data for each courier
        
        HeapMinPriorityQueue<Integer,Courier> couriers; //minPriorityQueue
        HeapMaxPriorityQueue<Integer,String> orders;    //maxPriorityQueue
       
        for(int i=1;i<=months;i++)
        {
            System.out.println("Month " + i + ":\n");   //Show month
            
            for(Integer j=0;j<m;j++)
            {
                //set the number of orders to 0 for couriers
                courierTotal[j] = 0;
                //Give name to each courer
                courierValues[j] = new Courier("courier " + j.toString());
            }
            
            for(Integer j=0;j<n;j++)
            {
                //random data in range [1...range]
                orderCust[j] = random.nextInt(range)+1;
                //set the customer name (including the number of X items in his order)
                customerNames[j] = "cust" + j.toString() + "(" + orderCust[j] + ")";
            }
            
            //new Queues using the above data
            orders = new HeapMaxPriorityQueue<Integer,String>(orderCust,customerNames);
            couriers = new HeapMinPriorityQueue<Integer,Courier>(courierTotal,courierValues);
            
            while(!orders.isEmpty())    
            {
                //remove max order from the MaxPriorityQueue
                Entry<Integer,String> maxOrder = orders.removeMax();
                //find a courier with the minimal number of items X
                Entry<Integer,Courier> minCourier = couriers.min();
                
                //add the customer's name in the courier's list
                minCourier.getValue().getCustomers().add(maxOrder.getValue());
                //change the courier's key
                Integer newKey = minCourier.getKey()+maxOrder.getKey();
                //downheap
                couriers.changeRoot(newKey);
            }
            
            //Print the courier in increasing order
            while(!couriers.isEmpty())
            {
                //remove min courier from the queue
                Entry<Integer,Courier> minCourier = couriers.removeMin();
                //courier's name
                System.out.println(minCourier.getValue().getName());
                //courier's customers
                System.out.println(minCourier.getValue().getCustomers().toString());
                //courier's total X items
                System.out.println("Courier's total X items: " + minCourier.getKey());
                System.out.println();
            }
          
            System.out.println();
        }
        
        
        
        
    }//main
}
