
/**
 * Test the class MyResizableIntArrayList
 * Eleni Stylianou ge21708
 * 25/03/2024
*/
public class TestDriver {
    public static void main(String[] args) {
        // Create an object MyResizableIntArrayList
        MyResizableIntArrayList myList = new MyResizableIntArrayList();

        // Add elements to the list
        myList.add(5);
        myList.add(10);
        myList.add(15);
        myList.add(20);

        // Show the elements of the list
        System.out.println("List Contents: ");
        for(int i=0;i<myList.size();i++){
            System.out.println(myList.get(i));
        }

        //Print the element in a specific location
        System.out.println("\nThe item in position 3: "+ myList.get(3));

        // Remove an element from the list
        myList.remove(1);
        System.out.println("\nList Contents after removal: ");
        for(int i=0;i<myList.size();i++){
            System.out.println(myList.get(i));
        }

        // Replace an element to the list
        myList.set(0, 25);
        System.out.println("\nList Contents after the modification: ");
        for(int i=0;i<myList.size();i++){
            System.out.println(myList.get(i));
        }

        // Add an element to a spescific location
        myList.add(1, 30);
        System.out.println("\nList Contents after adding: ");
        for(int i=0;i<myList.size();i++){
            System.out.println(myList.get(i));
        }
    
        //Checking if the list contains the element 15
        System.out.println("\nDoes list contain 15? "+ myList.contains(15));
        
        //Checking if the list is empty
        System.out.println("\nIs the list empty? "+ myList.isEmpty());
        
        //Print the size of the List
        System.out.println("\nThe size of the list is: "+ myList.size());
        
        //Remove all the elements from the list
        myList.clear();
        
        //Print the list after clearing
        System.out.println("\nList Contents after clearing: ");
        for(int i=0;i<myList.size();i++){
            System.out.println(myList.get(i));
        }
        
        //Checking again if the list is clear
        System.out.println("\nIs the list empty now? "+ myList.isEmpty());
    }
}
