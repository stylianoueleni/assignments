import java.util.ArrayList;

public class Courier
{
    
    private String name;
    private ArrayList<String> customers;
    
    public Courier(String courName)
    {
        name = courName;
        customers = new ArrayList<String>();
        //customers.clear();
    }//constructor
    
    public String getName() {return name;}
    
    public ArrayList<String> getCustomers() { return customers;}
    
    protected void setCustomers(ArrayList<String> newCustomers)
    {
        customers = newCustomers;
    }
    
}//Courier