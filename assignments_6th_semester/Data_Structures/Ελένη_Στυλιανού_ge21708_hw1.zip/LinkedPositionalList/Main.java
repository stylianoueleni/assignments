
/**
 * Familiarity with the use of class LinkedPositionalList
 *
 * Eleni Stylianou ge21708
 * 25/03/2024
 */
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        int n = 10; // Το πλήθος των τυχαίων αριθμών που θέλουμε να δημιουργήσουμε
        LinkedPositionalList<Double> list = new LinkedPositionalList<>();
        
        // Δημιουργία και εισαγωγή τυχαίων πραγματικών αριθμών στη λίστα
        generateRandomNumbers(list, n);
        
        //Εκτύπωση της αρχικής λίστας
        System.out.println("Οι αριθμοί της αρχικής λίστας:");
        printList(list);
        
        // Ταξινόμηση της λίστας με τη μέθοδο της επιλογής
        selectionSort(list);
        
        // Εκτύπωση των ταξινομημένων αριθμών
        System.out.println("Οι αριθμοί της ταξινομημένης λίστας:");
        printList(list);
    }
    
    // Μέθοδος για τη δημιουργία και εισαγωγή τυχαίων πραγματικών αριθμών σε μία λίστα
    public static void generateRandomNumbers(LinkedPositionalList<Double> list, int n) {
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            double randomNumber = random.nextDouble(); // Δημιουργία τυχαίου πραγματικού αριθμού
            list.addLast(randomNumber); // Εισαγωγή του πραγματικού αριθμού στη λίστα
        }
    }
    
    // Μέθοδος για την ταξινόμηση της λίστας με τη μέθοδο της επιλογής
    public static void selectionSort(LinkedPositionalList<Double> list) {
        if (list.size() <= 1) {
            return; // Η λίστα είναι ήδη ταξινομημένη ή περιέχει μόνο ένα στοιχείο
        }

        Position<Double> marker = list.first(); // Δείκτης που υποδεικνύει το σημείο όπου θα τοποθετηθεί ο επόμενος μικρότερος αριθμός

        while (marker != list.last()) {
            Position<Double> minPosition = marker; // Δείκτης για τον ελάχιστο αριθμό
            Position<Double> current = list.after(marker); // Δείκτης για τον τρέχοντα αριθμό

            // Εύρεση του ελάχιστου αριθμού στο υπόλοιπο τμήμα της λίστας
            while (current != null) {
                if (current.getElement() < minPosition.getElement()) {
                    minPosition = current;
                }
                current = list.after(current);
            }

            // Swap του ελάχιστου αριθμού με τον αριθμό στη θέση marker
            Double temp = minPosition.getElement();
            list.set(minPosition, list.set(marker, temp));

            marker = list.after(marker); // Μετακίνηση του δείκτη marker στην επόμενη θέση
        }
    }
    
    // Μέθοδος για την εκτύπωση των στοιχείων της λίστας
    public static void printList(LinkedPositionalList<Double> list) {
        for (Double number : list) {
            System.out.println(number);
        }
    }
}

