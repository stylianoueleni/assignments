import java.util.*;
public class PostFix
{
    /**
     * The user inputs a valid expression in postfix form and the result of
     * the expression in printed in the terminal.
     */
    public static void main(String args[])
    {
        System.out.println('\u000C');
        Scanner sc = new Scanner(System.in);
        String p;
        
        System.out.println("Give a regular postfix form:");
        p = sc.nextLine();
        System.out.println(p);
        
        System.out.print("The result of the above postfix form is: ");
        System.out.println(postfixEvaluate(p));
    }
    
    /**
     * Return the result of the given expression in postfix form.
     * The expression must be valid and not be enclosed in double quotes (" ").
     * 
     * @param pexp The expression in postfix form as a String.
     */
    private static double postfixEvaluate(String pexp)
    {
        double n,m;
        String p;
        LinkedStack<Double> stack = new LinkedStack<Double>();
        String[] elements = pexp.split(" ");
        
        for(int i=0;i<elements.length;i++)
        {
            if(isOperator(elements[i]))
                stack.push(operation(stack.pop(),stack.pop(),elements[i]));
            else
                stack.push(Double.parseDouble(elements[i]));
        }
        
        return stack.pop();
    }
    
    /**
     * Return true if the given String is one of the basic math operators (+,-,*,/)
     */
    private static boolean isOperator(String p)
    {
        if(p.equals("+") || p.equals("-") || p.equals("*") || p.equals("/"))
            return true;
        return false;
    }
    
    /**
     * Return the result of the operation between the numbers n and m
     * and the operator p (msn)
     * 
     * @param n a double number
     * @param m a double number
     * @param p the operator
     * @return msn
     */
    private static double operation(double n, double m, String p)
    {
        if(p.equals("+"))
            return m+n;
        else if(p.equals("-"))
            return m-n;
        else if(p.equals("*"))
            return m*n;
        return m/n;
    }  
}