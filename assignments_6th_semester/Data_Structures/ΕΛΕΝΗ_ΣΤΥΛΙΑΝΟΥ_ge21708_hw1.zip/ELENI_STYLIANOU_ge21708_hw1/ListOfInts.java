
/**
 * Write a description of class ListOfInts here.
 *
 * Eleni Stylianou
 * 01/04/2024
 */
public class ListOfInts implements Listt
{
    private int[] array;
    
    public ListOfInts(int n)
    {
        array = new int[n+1];
        for(int i=0;i<=n;i++)
            array[i] = 0;
    }
    
    public void insert(int i)
    {
        array[i]++;
    }
    
    public void delete(int i)
    {
        if(array[i] > 0)
            array[i]--;
    }
    
    public boolean member(int i)
    {
        return array[i]>0;
    }
}
