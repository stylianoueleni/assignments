import java.util.*;
public class RootCeil
{
    public static void main(String args[])
    {
        System.out.println('\u000C');
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Give a positive integer:");
        int n = sc.nextInt();
        
        while(n>0)
        {
            System.out.println("The ceiling of the square root of " + n + " is: " + ceilSqrt(n) );
            System.out.println("Give another positive integer (or 0 to stop):");
            n = sc.nextInt();
        }
    }
    
    /**
     * Return the ceiling of the square root of the given integer.
     * The given integer must be positive.
     */
    private static int ceilSqrt(int n)
    {
        int x,y0=0,yn=n;
        do
        {
            x = (y0+yn)/2;
            if(x*x == n)
                return x;
            else if(x*x > n)
                yn = x-1;
            else
                y0 = x+1;
        }while(y0<=yn);
        return y0;
    }
}