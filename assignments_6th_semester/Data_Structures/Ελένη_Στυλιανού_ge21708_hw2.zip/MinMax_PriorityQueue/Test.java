import java.util.*;

public class Test
{
    
    public static void main(String args[])
    {
        System.out.println('\u000C');
        Scanner sc = new Scanner(System.in);
        Random random = new Random();
        
        HeapMinMaxPriorityQueue q = new HeapMinMaxPriorityQueue();
        System.out.println("How many random numbers do you want to add to the queue?");
        Integer n = sc.nextInt(),x;
        
        while(n>0)
        {
            x = random.nextInt(1000);
            q.insert(x,x.toString());
            
            n--;
        }
        
        printQueueAndMaxs(q);
        
        n=1;
        while(n>0 && n<6)
        {
            System.out.println("MENU");
            System.out.println("1. min()");
            System.out.println("2. max()");
            System.out.println("3. insert()");
            System.out.println("4. removeMin()");
            System.out.println("5. removeMax()");
            System.out.println("6. EXIT");
            
            n = sc.nextInt();
            if(n==1)
                System.out.println("The current min of the queue is " + q.min().getValue());
            else if(n==2)
                System.out.println("The current max of the queue is " + q.max().getValue());
            else if(n==3)
                {
                    System.out.println("Which integer do you want to add to the queue?");
                    x = sc.nextInt();
                    q.insert(x,x.toString());
                }
            else if(n==4)
                System.out.println("The min that was removed from the queue is " + q.removeMin().getValue());
            else if(n==5)
                System.out.println("The max that was removed from the queue is " + q.removeMax().getValue());
            
            printQueueAndMaxs(q);
        }
        
    }
    
    public static void printQueueAndMaxs(HeapMinMaxPriorityQueue q)
    {
        System.out.print("MinMaxPriorityQueue: ");
        for(int i=0;i<q.heap.size();i++)
            System.out.print(q.get(i).getValue().toString() + ", ");
        System.out.println();
        System.out.println("maxDescenantValue:   " + q.maxDescenantValue.toString());
        System.out.println();
    }
    
}//main
    
