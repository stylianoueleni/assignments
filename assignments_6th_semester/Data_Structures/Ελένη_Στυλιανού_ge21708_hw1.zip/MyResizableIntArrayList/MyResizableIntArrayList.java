
/**
 * Creates a resizable array list
 * Eleni Stylianou ge21708
 * 25/03/2024
*/
import java.util.Arrays;

public class MyResizableIntArrayList
{   int size=0;//initialize the variable(size of the list)
    int data[];//create a vector to save the integers

    /**
     * Constracts a resizable array-list of integers with capacity=1.
     */
    public MyResizableIntArrayList()
    {
       data=new int[1];//initialize with size 1
    }
    
     /**
     * Constracts a resizable array-list of integers with the capacity given by the user.
     * initialCapacity - The initial capacity of the resizable array-list.
     */
    public MyResizableIntArrayList(int initialCapacity)
    {
       data=new int[initialCapacity];//initialize with the specified size      
    }
    
    /**
     * Appends a spesific element to the end of the resizable array-list.
     * elem - The element to be appended.
     */
    public void add(int elem)
    {        
        if(size>=data.length){
            int newData[]=Arrays.copyOf(data,data.length*2);//Dublicate table size
            data=newData;
        } 
        data[size++]=elem;//appends the element and increase the table size by 1
    }
    
    /**
     * Inserts the specified element at the specified location in the resizable array-list.
     * index - The index of the new element after it is inserted. It MUST hold that (index >= 0 && size() >=index).
     * elem - The element to be inserted.
     */
    public void add (int index,int elem)
    {
        if(index>=0 && index<=size){
            if(size>=data.length){
                int newData[]=Arrays.copyOf(data,data.length*2);//Dublicate table size
                data=newData;
            } 
            int temp=0;
            for (int i=size-1;i>=index;i--){     
                data[i+1]=data[i];//move the elements to make space for the new one
            }
            data[index]=elem;//adding the new element
            size+=1;//increase the size of the list by 1
        }
        else 
           throw new IndexOutOfBoundsException(index);
    }
    
    /**
     * Removes all the elements of the array-list and resets its capacity to 1.
     */
    public void clear()
    {
        data=new int[1];
        size=0;
    }
    
    /**
     * Checks whether this array-list contains a specific element.
     * elem - The element in question
     */
    public boolean contains(int elem)
    {
        for (int i=0;i<size;i++){
            if(data[i]==elem)
                return true;
        }
        return false;
    }
    
     /**
    * Tests whether the array list is empty.
    * @return true if the array list is empty, false otherwise
    */
    public boolean isEmpty() { return size == 0; }
    
     /**
     * Removes the element at the specified position in this array-list.
     * index - The position of the element to be removed. It MUST hold that (index >= 0 && size() > index).
     */
    public void remove(int index)
    {
        for (int i=index;i<size-1;i++){ 
            data[i]=data[i+1];//move the elements
        }
        data[size-1]=0;
        size-=1;
        if(4*size==data.length){
            int newData[]=Arrays.copyOf(data,data.length/2);//Divide table size by 2
            data=newData;
        }
    }
    
     /**
     * Replaces the element at the specified position in this array-list with the specified element.
     * index - The index of the element to be replaced. It MUST hold that (index >= 0 && size() >index).
     * elem - The new element.
     */
    public void set(int index, int elem)
    {
        if(index<=size)
            data[index]=elem;
        else
            throw new IndexOutOfBoundsException(index);
    }
    
     /**
     * The size of this array-list.
     */
    public int size()
    {
        return size;
    }

    /**
     * Returns the element from a specific location
     */
    public int get(int index){
        if(index<=size)
            return data[index];
        else
            throw new IndexOutOfBoundsException(index);
    }
}
