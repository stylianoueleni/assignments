
/**
 * A list of elements E
 *
 * Eleni Stylianou
 * 01/04/2024
 */
public interface Listt
{
    /**
     * Insert the element e in the list.
     */
    public void insert(int i);
    
    /**
     * Delete the element e from the list.
     */
    public void delete(int i);
    
    /**
     * Return true if the element is in the list, false otherwise.
     */
    public boolean member(int i);
}
