import java.util.ArrayList;
import java.util.Comparator;

/**
 * An implementation of a min-max priority queue using an array-based heap.
 */
public class HeapMinMaxPriorityQueue<K,V> extends AbstractPriorityQueue<K,V> {
  /** primary collection of priority queue entries */
  protected ArrayList<Entry<K,V>> heap = new ArrayList<>();
  protected ArrayList<K> maxDescenantValue = new ArrayList<K>();

  /** Creates an empty priority queue based on the natural ordering of its keys. */
  public HeapMinMaxPriorityQueue() { super(); }

  /**
   * Creates an empty priority queue using the given comparator to order keys.
   * @param comp comparator defining the order of keys in the priority queue
   */
  public HeapMinMaxPriorityQueue(Comparator<K> comp) { super(comp); }

  // protected utilities
  protected int parent(int j) { return (j-1) / 2; }     // truncating division
  protected int left(int j) { return 2*j + 1; }
  protected int right(int j) { return 2*j + 2; }
  protected boolean hasLeft(int j) { return left(j) < heap.size(); }
  protected boolean hasRight(int j) { return right(j) < heap.size(); }

  /** Exchanges the entries at indices i and j of the array list. */
  protected void swap(int i, int j) {
    Entry<K,V> temp = heap.get(i);
    heap.set(i, heap.get(j));
    heap.set(j, temp);
  }

  /** Moves the entry at index j higher, if necessary, to restore the heap property. */
  protected void upheap(int j) {
    while (j > 0) {            // continue until reaching root (or break statement)
      int p = parent(j);
      if (compare(heap.get(j), heap.get(p)) >= 0) break; // heap property verified
      swap(j, p);
      j = p;                                // continue from the parent's location
    }
  }

  /** Moves the entry at index j lower, if necessary, to restore the heap property. */
  protected int downheap(int j) {
    while (hasLeft(j)) {               // continue to bottom (or break statement)
      int leftIndex = left(j);
      int smallChildIndex = leftIndex;     // although right may be smaller
      if (hasRight(j)) {
          int rightIndex = right(j);
          if (compare(heap.get(leftIndex), heap.get(rightIndex)) > 0)
            smallChildIndex = rightIndex;  // right child is smaller
      }
      if (compare(heap.get(smallChildIndex), heap.get(j)) >= 0)
        return j;                             // heap property has been restored
      swap(j, smallChildIndex);
      j = smallChildIndex;                 // continue at position of the child
    }
    return j;
  }
  
  /**
   * update the maxDescenantValue for all the ancestors of the current entry.
   */
  private void update(int i) throws IndexOutOfBoundsException
  {
  int leftChild,rightChild;
  boolean continuee=true;
  while(continuee)
  {
      leftChild = left(i);
      if(hasRight(i))           //two children case
      {
          rightChild = right(i);
          K rightMax = maxDescenantValue.get(rightChild);
          K leftMax = maxDescenantValue.get(leftChild);
          if(((Comparable<K>) leftMax).compareTo(rightMax) > 0 )    //left child is bigger
            maxDescenantValue.set(i, maxDescenantValue.get(leftChild));
          else          //right child is not smaller than left child
            maxDescenantValue.set(i, maxDescenantValue.get(rightChild));
        }
      else if(hasLeft(i))       //only left child case
        maxDescenantValue.set(i, maxDescenantValue.get(leftChild));
      else if(!heap.isEmpty())  //no children case (leaf), assuming heap is not empty
        maxDescenantValue.set(i,heap.get(i).getKey());
      
      if(i==0 || maxDescenantValue.get(parent(i)).equals(maxDescenantValue.get(i)))
        continuee=false;        //stop if i==root or no more changes needed
      i = parent(i);            //update the parent
    }
  }//update
  
  /**
   * 
   */
  protected Entry<K,V> get(int i)
  {
      return heap.get(i);
    }//get
    
  /**
   * return the position in the ArrayList of the Entry with the maximal key.
   * Follow the path from the root to the max leaf based on the values of the
   * maxDescenantValue ArrayList.
   */
  private int maxPos()
  {
      if(heap.isEmpty())
        return -1;
      int temp=0;
      while(hasLeft(temp))
      {
          if(maxDescenantValue.get(left(temp)).equals(maxDescenantValue.get(temp)))
            temp = left(temp);      //max descenant comes from the left child
          else
            temp = right(temp);     //max descenant comes from the right child
        }
      return temp;
    }

  // public methods

  /**
   * Returns the number of items in the priority queue.
   * @return number of items
   */
  @Override
  public int size() { return heap.size(); }

  /**
   * Returns (but does not remove) an entry with minimal key.
   * @return entry having a minimal key (or null if empty)
   */
  @Override
  public Entry<K,V> min() {
    if (heap.isEmpty()) return null;
    return heap.get(0);
  }
  
  /**
   * Return the entry with the maximal key.
   */
  @Override
  public Entry<K,V> max()
  {
      if(heap.isEmpty())
        return null;
      return heap.get(maxPos());
  }//max

  /**
   * Inserts a key-value pair and return the entry created.
   * @param key     the key of the new entry
   * @param value   the associated value of the new entry
   * @return the entry storing the new key-value pair
   * @throws IllegalArgumentException if the key is unacceptable for this queue
   */
  @Override
  public Entry<K,V> insert(K key, V value) throws IllegalArgumentException {
    checkKey(key);      // auxiliary key-checking method (could throw exception)
    Entry<K,V> newest = new PQEntry<>(key, value);
    heap.add(newest);                      // add to the end of the list
    maxDescenantValue.add(null);            // add the key to the end of the maxDescenantValue list
    upheap(heap.size() - 1);               // upheap newly added entry
    update(maxDescenantValue.size()-1);    //update the maxDescenant values
    return newest;
  }

  /**
   * Removes and returns an entry with minimal key.
   * @return the removed entry (or null if empty)
   */
  @Override
  public Entry<K,V> removeMin() {
    if (heap.isEmpty()) return null;
    Entry<K,V> answer = heap.get(0);
    int lastParent = parent(heap.size()-1);// remember the parent of the last Entry
    swap(0, heap.size() - 1);              // put minimum item at the end
    heap.remove(heap.size() - 1);          // and remove it from the list;
    update(lastParent);                    // update the maxDescenant values as the last Entry has been removed
    update(downheap(0));                   // then fix new root and update the maxDescenant values
    maxDescenantValue.remove(heap.size()); // decrease the size of the maxDescenantValue
    return answer;
  }
  
  /**
   * Removes and returns an entry with maximal key.
   * @return the removed entry (or null if empty)
   */
  @Override
  public Entry<K,V> removeMax()
  {
      if (heap.isEmpty()) return null;
      int max = maxPos();
      Entry<K,V> maxEntry = heap.get(max);
      int lastParent = parent(heap.size()-1);
      swap(max, heap.size() - 1);               // put maximum item at the end
      heap.remove(heap.size() - 1);             // and remove it from the list;
      update(lastParent);
      if(max<heap.size()){          //check that max was not in the last position
          upheap(max);
          update(max);
      }
      maxDescenantValue.remove(heap.size());      
      return maxEntry;
    }//removeMax

  /** Used for debugging purposes only */
  private void sanityCheck() {
    for (int j=0; j < heap.size(); j++) {
      int left = left(j);
      int right = right(j);
      if (left < heap.size() && compare(heap.get(left), heap.get(j)) < 0)
        System.out.println("Invalid left child relationship");
      if (right < heap.size() && compare(heap.get(right), heap.get(j)) < 0)
        System.out.println("Invalid right child relationship");
    }
  }
}
